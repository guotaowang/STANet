import torch.nn as nn
import torch
import torch.nn.functional as F
affine_par = True
from ConvGRU import ConvGRUCell
import cv2
import numpy as np
import torch
import torch.nn.init

model_urls = {'resnext101_32x8d': 'https://download.pytorch.org/models/resnext101_32x8d-8ba56ff5.pth',
'vgg16': 'https://download.pytorch.org/models/vgg16-397923af.pth'}

class SNetModel(nn.Module):
    def  __init__(self, middir):
        super(SNetModel, self).__init__()
        
        self.extra_convs = nn.Conv2d(1024, 28,1)
        all_channel = 28
        self.extra_conv_fusion = nn.Conv2d(all_channel*2, all_channel, kernel_size=1, bias=True)
        self.extra_ConvGRU = ConvGRUCell(all_channel, all_channel, kernel_size=1)

        self.extra_gate = nn.Conv2d(all_channel, 1, kernel_size = 1, bias = False)
        self.extra_gate_s = nn.Sigmoid()

        self.extra_projf = nn.Conv2d(in_channels=all_channel, out_channels=all_channel // 2 , kernel_size=1)
        self.extra_projg = nn.Conv2d(in_channels=all_channel, out_channels=all_channel // 2 , kernel_size=1)
        self.extra_projh = nn.Conv2d(in_channels=all_channel, out_channels=all_channel , kernel_size=1)

        self.middir = middir

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                m.weight.data.normal_(0, 0.01)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_() 

        net = torch.hub.load('facebookresearch/WSL-Images','resnext101_32x8d_wsl')
        net = list(net.children())
        self.features = nn.Sequential(*net[:7])

    		
    def forward(self, idx,  img_name1, input1, epoch=1, label=None, index=None):
   
        x1 = self.features(input1) # 1,512,32,32
        x1 = self.extra_convs(x1) # 1,28,32,32
        x2 = self.extra_conv_fusion(torch.cat((x1, self.self_attention(x1)), 1))
        x2 = self.extra_ConvGRU(x2, x1)
        
        self.map_1 = x1.clone() # 1,28,32,32
        x1ss = F.avg_pool2d(x1, kernel_size=(x1.size(2), x1.size(3)), padding=0) # 1,28,1,1
        x1ss = x1ss.view(-1, 28) # 1,28

        self.map_2 = x2.clone() # 1,28,32,32
        x2ss = F.avg_pool2d(x2, kernel_size=(x2.size(2), x2.size(3)), padding=0) # 1,28,1,1
        x2ss = x2ss.view(-1, 28) # 1,28
       
        return x1ss, x2ss, self.map_1, self.map_2

    def self_attention(self, x):
        m_batchsize, C, width, height = x.size() # 8,28,32,32
        
        f = self.extra_projf(x).view(m_batchsize, -1, width * height) # B * (C//8) * (W * H) # 8,14,1024
        g = self.extra_projg(x).view(m_batchsize, -1, width * height) # B * (C//8) * (W * H) # 8,14,1024
        h = self.extra_projh(x).view(m_batchsize, -1, width * height) # B * C * (W * H)      # 8,28,1024
        
        attention = torch.bmm(f.permute(0, 2, 1), g) # B * (W * H) * (W * H)
        attention = F.softmax(attention, dim=1)  # 8,1024,1024
        
        self_attetion = torch.bmm(h, attention) # B * C * (W * H)
        self_attetion = self_attetion.view(m_batchsize, C, width, height) # B * C * W * H
        self_mask = self.extra_gate(self_attetion)                                       #[1, 1, 32, 32]
        self_mask = self.extra_gate_s(self_mask)
        out = self_mask * x
        return out

    def get_parameter_groups(self):
        groups = ([], [], [], [])
        for name, value in self.named_parameters():

            if 'extra' in name:
                if 'weight' in name:
                    groups[2].append(value)
                else:
                    groups[3].append(value)
            else:
                if 'weight' in name:
                    groups[0].append(value)
                else:
                    groups[1].append(value)
        return groups

